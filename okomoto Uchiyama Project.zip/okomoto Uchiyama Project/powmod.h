string powmod(string a,string b,string n)
{
    string f,c,zero="0",r,q,binary_s;
    int i,j,k;
     f="1";
    
    while(sub(b,zero)!=zero)
    {
                              
    //  cout<<"inside"<<b.length()<<"    "<<b<<endl;
      
      binary_s+=(mod(b,"2"));
      b=div(b,"2");
    }
    binary_s=strrev(binary_s);
    //cout<<"Binary representation"<<endl<<binary_s;
    
    for(i=0;i<binary_s.length();i++)
    {
     if(binary_s[i]=='0')
     {
          //cout<<"inside ZERO";                
          f=mul(f,f);                
     }
     else
     {
         f=mul(f,f);
         f=mul(f,a);
     }                                  
    f=mod(f,n);
    }
    //cout<<endl<<f;
    return f;
    
}

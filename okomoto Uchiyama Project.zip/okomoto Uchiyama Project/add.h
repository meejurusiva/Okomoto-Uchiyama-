//#include<iostream>
//#include<cstring>
#include"trim_0.h"
using namespace std;

string strrev(string s)
{	int i=0,j=s.length()-1;
	char t;
	while (i<j) 
	{
		t=s[j];
		s[j]= s[i];
		s[i]=t;
		i++;
		j--;
	}return s;
}

string add(string a, string b )
{     //string a,b;
      string sum,temp;
      //cin>>a>>b;
      a= trim_0(a);
      b= trim_0(b);
      //cout<<a<<endl<<b<<endl;
      int len_a,len_b,sm,num,cry=0;
      len_a= a.length();
      len_b= b.length();
      //cout<<len_a<<endl;
      if (len_a<len_b)
         {            temp=a;
                      a=b;
                      b=temp;
                      }
      //cout<<a<<endl<<b<<endl;
      len_a= a.length();
      len_b= b.length();
      a= strrev(a);
      b= strrev(b);
      //cout<<a<<endl<<b<<endl;
      int i;
      for(i=0;i<len_b;i++)
      {                   sm =a[i]-48+b[i]-48+cry;
                          num= sm%10;
                          cry= sm/10;
                          sum+= (char)(num+48);
                         // cout<<sum[i]<<endl;
      }
      for(;i<len_a;i++)
      {                   sm =a[i]-48+cry;
                          num= sm%10;
                          cry= sm/10;
                          sum+= (char)(num+48);
                         // cout<<sum[i]<<endl;
      }
      if (cry>0)
      sum+= (char)(cry+48);         
      //sum[i] ='\0';
      //cout<<sum<<endl;
      sum =strrev(sum);
      //cout<<sum;
      //cin>>i;
      return (sum);
      }

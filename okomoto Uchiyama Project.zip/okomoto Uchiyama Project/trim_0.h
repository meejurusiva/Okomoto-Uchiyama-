//#include<iostream>
//#include<cstring>
using namespace std;

string trim_0(string a)
{     //string a;
      //cin>>a;
      int i=0;
      while(a[i]=='0'&& a[i+1]!='\0')
      {                 i++; 
                        }
      //cout<<i<<endl;
      a = a.substr(i);                  
      //cout<<a;
      //cin>>i;
      return(a); 
      }

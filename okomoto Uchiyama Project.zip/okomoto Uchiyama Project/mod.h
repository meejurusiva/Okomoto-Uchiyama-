//#include<iostream>
//#include<cstring>
//#include<string>
//#include"trim_0.h"
//#include"add.h"
//#include"sub.h"
using namespace std;

string mod(string a,string b)
{     string que="0",rmain,aa,bb,temp;
      //cin>>a>>b;
      //cout<<a<<endl<<b<<endl;
      a= trim_0(a);
      b= trim_0(b);
      int len_a,len_b,div,num,cry=0;
      len_a= a.length();
      len_b= b.length();
      //cout<<len_a<<endl;
      if (b=="0")
         return(0);
      else if((len_a<len_b)||(len_a==len_b && (a.compare(b)<0)))
         {
         que= "0";
         rmain= a;
         }
         else if (len_a==len_b && (a.compare(b)==0))
         {
         que= "1";
         rmain= "0";
          }
          //if a>b
           else
           {   aa=a;
               bb=b;
               //if length aa>b
               int i,n;
               while (aa.length()>b.length())
                     {//1st element of aa > b
                     if (aa[0]>b[0])
                        {
                        temp= "1";
                        ///int i,n;
                        n= aa.length()-b.length();
                        for(i=0;i<n;i++)
                            {temp+= '0';
                            bb+= '0';
                            }
                        }
                        else //1st element of aa < b
                            {
                            temp= "1";
                            //int i,n;
                            n= aa.length()-b.length();
                            for (i=0;i<n-1;i++)
                                {temp+= '0';
                                bb+= '0';
                                }
                            }
                        que= add(que,temp);
                        aa= sub(aa,bb);
                        bb=b;
                        }
                while ((aa.length()==b.length())&&(aa.compare(b)>0||(aa.compare(b)==0)))
                      {temp= "1";
                      que= add(que,temp);
                      aa= sub(aa,bb);
                      }
                      rmain=aa;

              }

      //cout<<que<<endl<<rmain<<endl;
      //cin>>a;
      return rmain;
      }

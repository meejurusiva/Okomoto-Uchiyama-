//#include <stdio.h>
//#include <conio.h>
//#include<iostream>
//#include<cstring>
//#include<string>
//#include"trim_0.h"
using namespace std;


/*string strrev(string s)
{	int i=0,j=s.length()-1;
	char t;
	while (i<j) 
	{
		t=s[j];
		s[j]= s[i];
		s[i]=t;
		i++;
		j--;
	}return s;
}*/

string sub(string a,string b)
{	//clrscr();
	//string a,b;
    string sub;
	//cin>>a;
	//cin>>b;
	a= trim_0(a);
	b= trim_0(b);
	//cout<<a;
	//cout<<b;
	int len_a,len_b,sb,brw=0;
	len_a = a.length();
	len_b = b.length();
	//cout<<len_a<<endl;
	if (len_b>len_a)
	{	string temp;
		temp=a;
		a=b;
		b=temp;
	}
	if (len_a==len_b && (a.compare(b)<0))
	{	string temp;
		temp= a;
		a=b;
		b=temp;
	}
	//cout<<a<<endl<<b<<endl;
	len_a = a.length();
	len_b = b.length();
	a=strrev(a);
	b=strrev(b);
	//cout<<a<<endl;
	//cout<<b<<endl;
	int i;
	for (i=0;i<len_b;i++)
	{	if (a[i]<(b[i]+brw))
        {     sb = (a[i]-48)-(b[i]-48)+10-brw;
	  	      brw=1;
		      sub+= (char)(sb+48);
		      //cout<<sub[i]<<endl;
	       }
	       else
	       {	sb = (a[i]-48)-(b[i]-48)-brw;
		        brw=0;
                sub+=(char)(sb+48);
                //cout<<sub[i]<<endl;
	            }
	}
	for (;i<len_a;i++)
	    {      sb = (a[i]-48)-brw;
		        if (sb<0)
		        {	sb = sb+10;
                    brw =1;
			        //sub[i]=(char)(sb+48);
                    }
                    else
			            brw = 0;
	         sub+=(char)(sb+48);
	         //cout<<sub[i]<<endl;
          }
          
    //cout<<"i="<<i<<endl;      
	sub[i]=(char)'\0';
	sub =strrev(sub);
	//string sub1= sub;
	//cout<<sub<<endl;
	//cin>>i;
	//getch();
	sub= trim_0(sub);
	return (sub);
}

#include<time.h>
#include "isprime.h"
string generateprime(int k)
{
    string a,zero="0";
    int i;
    time_t seconds;
    seconds=time(NULL);
    srand(seconds);
    a="1";
    for(i=0;i<k;i++)
    {
      if((rand()%2)==1)
      {
         a=mul(a,"2");
         a=add(a,"1");
      }        
      else
      {
          a=mul(a,"2");
      }      
      //cout<<endl<<a<<endl;
    }
    if(mod(a,"2")==zero)
    a=add(a,"1");
    while(!isprime(a,1000))
    {
      a=add(a,"2");
    }
return a;    
       
}

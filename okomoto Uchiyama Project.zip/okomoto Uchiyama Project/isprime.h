#include<stdlib.h>
//tested by using miller rabin primality test
bool compare(string, string);
bool isprime(string n, int k) 
{
    bool flag=false;
	string temp,d,zero="0",x;
	int i,r,random,s=0,Min=2,Max=100;
    temp=sub(n,"1");
	
	while(mod(temp,"2")!=zero)
	{
		s++;
		temp=div(temp,"2");
	}
	
	d=temp;

	random=rand()%100;
	/////////
	while(random!=0)
    {
               x+=(char)(random%10+48);
               random=random/10;
    }
    x=strrev(x);
	
	for(i=0;i<k;i++)
	{
		x=powmod(x,d,n);
		if(compare(x,"1")||compare(x,sub(n,"1")))
		{
			
		}
		else
		{
			return false;
		}
		for(r=1;r<=(s-1);r++)
		{
			x=powmod(x,"2",n);
			if(compare(x,"1"))
				return false;
			if(compare(x,sub(n,"1")))
			{
				break;
			}
		}
	}
	return true;
}


bool compare(string a,string b)
{
    string zero="0",one="1";
    if((div(a,b)==one)&&(mod(a,b)==zero))
    return true;
    else 
    return false;
}

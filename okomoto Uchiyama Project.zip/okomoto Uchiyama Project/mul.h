
#include<iostream>
#include<cstring>
#include<string>
#include"add.h"
using namespace std;


/*string strrev(string s)
{	int i=0,j=s.length()-1;
	char t;
	while (i<j) 
	{
		t=s[j];
		s[j]= s[i];
		s[i]=t;
		i++;
		j--;
	}return s;
}*/

//main()
string mul(string a,string b)
{     string mul="0",temp;
      //cin>>a>>b;
      //cout<<a<<endl<<b<<endl;
      a= trim_0(a);
      b= trim_0(b);
      int len_a,len_b,ml,num,cry=0;
      len_a= a.length();
      len_b= b.length();
      //cout<<len_a<<endl;
      if (len_a<len_b)
         {            temp=a;
                      a=b;
                      b=temp;
                      }
      //cout<<a<<endl<<b<<endl;
      len_a= a.length();
      len_b= b.length();
      a= strrev(a);
      b= strrev(b);
      //cout<<a<<endl<<b<<endl;
      int i,j;
      temp.erase(0);
      for (i=0;i<len_b;i++)
          {
          for (j=0;j<len_a;j++)
               {   ml = (a[j]-48)*(b[i]-48)+cry;
                   num = ml%10;
                   cry = ml/10;
                   temp+= (char)(num+48);
               }
          temp+= (char)(cry+48);
          temp = strrev(temp);
          //cout<<temp<<endl;
          for (j=i;j>0;j--)
          {   temp+= '0';
          }
           
           mul = add(mul,temp);
           temp.erase(0);
           cry=0;
           }
           //cout<<mul;     
      return mul;
      //cin>>i;
      }
